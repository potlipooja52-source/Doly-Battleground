# Doly Battleground (v0.2: 2D mode + 3D mode)

Android Studio project. App name: **Doly Battleground**, package `com.doly.battleground`.
Your logo is the launcher icon (`res/mipmap-*`) and the menu logo (`assets/logo.png`).
A 512x512 copy for the Play Store is in `playstore-icon-512.png`.

## Run it
1. Open this folder in Android Studio (it will create the Gradle wrapper on sync).
2. Press Run on a device or emulator, or Build > Build APK(s).
3. To test in a browser first: open `app/src/main/assets/index.html`.

## Controls
Touch: drag on the left side to move, hold FIRE. Aim is automatic toward the nearest enemy.
Keyboard: WASD or arrows to move, Space to fire.

## Included in Stage 1
Menu with nickname, 20-player survival (you + 19 bots), loot (health and ammo),
shrinking safe zone, minimap, kills and placement screen.

## 3D mode (new)
Pick "3D MODE" on the menu (`assets/game3d.html`). Own WebGL engine, no downloads needed, works offline.
Parachute drop, third-person camera, 3D buildings, loot, shrinking zone wall, 19 bots.
Touch: left stick moves, drag the right side to turn the camera, hold FIRE (aims at the nearest enemy).
Keyboard: WASD move, Q/E or arrow keys turn, Space fire.

## Next
Stage 2: better graphics, maps and menus. Edit `assets/index.html`; the Kotlin wrapper rarely changes.
