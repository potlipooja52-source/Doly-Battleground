plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.doly.battleground"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.doly.battleground"
        minSdk = 24; targetSdk = 34
        versionCode = 2; versionName = "0.2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
